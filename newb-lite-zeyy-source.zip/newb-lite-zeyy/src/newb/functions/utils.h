#ifndef UTILS_H
#define UTILS_H

#define PI 3.141592
#define PI_HALF 1.570796
#define PI_QUART 0.785398

mat2 rmat2(float t) {
  float sint = sin(t);
  float cost = cos(t);
  return mtxFromRows(vec2(cost, -sint), vec2(sint, cost));
}

float degToRad(float t) { return 0.0174533*t; }

// sama dengan mul(rmat2(t), v) tapi dalam bentuk skalar:
// kalau t konstan 0, cos/sin terlipat dan tidak ada perkalian matriks tersisa
vec2 rotate2(vec2 v, float t) {
  float c = cos(t);
  float s = sin(t);
  return vec2(c*v.x - s*v.y, s*v.x + c*v.y);
}

float luminance(vec3 x) { return dot(x, vec3(0.21, 0.71, 0.08)); }

#endif
